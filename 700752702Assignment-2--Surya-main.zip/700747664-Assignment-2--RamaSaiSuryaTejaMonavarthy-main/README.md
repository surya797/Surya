# 700747664-Assignment-2--RamaSaiSuryaTejaMonavarthy


Hi Professor here is the link of video recording for 2nd assignment
https://drive.google.com/file/d/1nyaxYZ771zt130BD27hOdQ1zE6Qvmgh5/view?usp=drive_link
